/********
 * Name: Maninderjit Singh
 * Date: December 8, 2022
 * Assignmnent: Lab5
 * 
 ********/

using System;

namespace NETD_Lab5.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
